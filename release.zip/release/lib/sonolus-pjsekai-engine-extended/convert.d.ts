import { type LevelData } from "@sonolus/core";
import { type USC } from "usctool";
export declare const uscToLevelData: (usc: USC, offset?: number) => LevelData;
